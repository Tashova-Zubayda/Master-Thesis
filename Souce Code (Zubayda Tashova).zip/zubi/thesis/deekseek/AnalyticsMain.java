
package zubi.thesis.deekseek;

import static zubi.thesis.deekseek.DeekSeek.analyticsSort;
import static zubi.thesis.deekseek.DeekSeek.normalize;
import zubi.thesis.deekseek.Models.Analytics;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;



public class AnalyticsMain implements java.io.Serializable{
    
    public static void analyticsSentiment(String folder, String fileName){
        try{
            
            int positiveRep = 0,positiveDem = 0;
            int negativeRep = 0,negativeDem = 0;
            int neutralRep = 0,neutralDem = 0;
            
            HashMap<String, Analytics> analyticsHash = new HashMap<>();
            HashMap<String, String> classification = new HashMap<>();
            HashMap<String, String> sentiment = new HashMap<>();
            HashMap<String, String> topic = new HashMap<>();
            
            HashMap<String, String> test = new HashMap<>();
            
            
            try (BufferedReader br = new BufferedReader(new FileReader(folder+"MERGED_CLASS_0_3.csv"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        line = line.replaceAll("\\$\\$##\\$\\$", "\\$\\$");
                        String[] values = line.split("\\$\\$");
                        List<String> lineData = Arrays.asList(values);
                        classification.put(lineData.get(0), lineData.get(2));
                        
                        test.put(lineData.get(0), lineData.get(1));
                    }
            }
            
            try (BufferedReader br = new BufferedReader(new FileReader(folder+"MERGED_TOPIC_0_3.csv"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        line = line.replaceAll("\\$\\$##\\$\\$", "\\$\\$").replaceAll("\"", "").toUpperCase();
                        String[] values = line.split("\\|");
                        List<String> lineData = Arrays.asList(values);
                        String topicMain = normalize(lineData.get(2)).replaceAll("\\'S","").replaceAll(": ", "")
                                        //.replaceAll("DONALD TRUMP", "DONALD-TRUMP")
                                        //.replaceAll("JOE BIDEN", "JOE-BIDEN")
                                        .replaceAll("TOPIC", "")
                                        .replaceAll("TRUMP CRITICISM", "DONALD TRUMP CRITICISM")
                                        .replaceAll("TRUMP SUPPORTER", "TRUMP SUPPORTERS")
                                        .replaceAll("BIDEN ADMINISTRATION CRITICISM", "BIDEN CRITICISM")
                                        .replaceAll("POLITICS BIDEN CRITICISM", "BIDEN CRITICISM").replaceAll("CRITICISM OF BIDEN", "BIDEN CRITICISM")
                                        .replaceAll("IMMIGRATION RHETORIC", "IMMIGRATION POLICY");
                                
                        topic.put(lineData.get(0), topicMain);
                    }
            }
            
            try (BufferedReader br = new BufferedReader(new FileReader(folder+"MERGED_SENTIM_0_3.csv"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        line = line.replaceAll("\\$\\$##\\$\\$", "\\$\\$");
                        String[] values = line.split("\\$\\$");
                        List<String> lineData = Arrays.asList(values);
                        sentiment.put(lineData.get(0), lineData.get(2).replaceAll("\"", "").toUpperCase());
                        
                        
                        if(classification.get(lineData.get(0)) != null){
                            if(sentiment.get(lineData.get(0)).contains("POS")){
                                if(classification.get(lineData.get(0)).contains("REPUB")){
                                    positiveRep = positiveRep+1;
                                }
                                else{
                                    positiveDem = positiveDem+1;
                                }
                                
                            }
                            else if(sentiment.get(lineData.get(0)).contains("NEG")){
                                if(classification.get(lineData.get(0)).contains("REPUB")){
                                    negativeRep = negativeRep+1;
                                }
                                else{
                                    negativeDem = negativeDem+1;
                                }
                            }
                            else{
                                if(classification.get(lineData.get(0)).contains("REPUB")){
                                    neutralRep = neutralRep+1;
                                }
                                else{
                                    neutralDem = neutralDem+1;
                                }
                            }
                        }
                        
                        
                    }
            }
            
            for (Entry<String, String> entry : topic.entrySet()) {
                    if (entry.getValue().equals("DONALD TRUMP")) {
                        //System.out.println(sentiment.get(entry.getKey())+", "+classification.get(entry.getKey())+" | "+test.get(entry.getKey()));
                    }
            }
            
            
            System.out.println("Positive Republican: "+positiveRep+" , Negative : " +negativeRep+" , Neutral : "+neutralRep+" => "+(double)(negativeRep/26000));
            System.out.println("Positive Democrat: "+positiveDem+" , Negative : " +negativeDem+" , Neutral : "+neutralDem+" => "+(double)(negativeDem/14000));
            
            
                try (BufferedReader br = new BufferedReader(new FileReader(folder+fileName))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        String[] values = line.split(",");
                        List<String> lineData = Arrays.asList(values);
                        
                        if(lineData.get(10) != null && lineData.get(10).length() > 0){
                            
                            //System.out.println(lineData.get(10));
                            String ID = lineData.get(0); 
                            
                            
                            
                            for(int l = 0; l < 2; l++){
                                
                                    if(lineData.size() > 20){
                                        
                                        int inclinationDem = 0; int inclinationRep = 0; 
                                        if(classification.get(ID) != null && classification.get(ID).contains("REP")) inclinationRep = 1;  
                                        else inclinationDem = 1;
                                        if(analyticsHash.containsKey(normalize(sentiment.get(l)))){
                                            Analytics analytics = analyticsHash.get(normalize(sentiment.get(l)));
                                            analytics.setTweetCount(analytics.getTweetCount()+1);
                                            analytics.setInclinationDem(analytics.getInclinationDem()+inclinationDem);
                                            analytics.setInclinationRep(analytics.getInclinationRep()+inclinationRep);
                                            if(classification.get(ID) != null && !analytics.getClassification().contains(classification.get(ID))) analytics.setClassification("MIXED");
                                        }
                                        else{
                                            Analytics analytics = new Analytics(normalize(sentiment.get(l)), lineData.get(13), lineData.get(14), classification.get(ID), inclinationDem , inclinationRep );
                                            analyticsHash.put(normalize(sentiment.get(l)), analytics);
                                        }
                                    }
                                
                            }
                            
                            
                        }
                        
                        

                    }
                }
                
                
                ArrayList<Analytics> arrayList = new ArrayList<Analytics>(analyticsHash.size());
                arrayList.addAll(analyticsHash.values());
                
                analyticsSort(arrayList);
                int count = 0;
                for(int i = 0; i < 500; i++){
                    if(arrayList.get(i).getTweetCount() > 3){
                        System.out.println(arrayList.get(i));
                        count++;
                    }
                    if(count == 35) break;
                }
                
                
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public static void analyticsLocation(String folder, String fileName){
        try{
            
            int republican = 0;
            int democtat = 0;
            
            HashMap<String, Analytics> analyticsHash = new HashMap<>();
            HashMap<String, String> classification = new HashMap<>();
            
            try (BufferedReader br = new BufferedReader(new FileReader(folder+"MERGED_CLASS_0_3.csv"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        line = line.replaceAll("\\$\\$##\\$\\$", "\\$\\$");
                        String[] values = line.split("\\$\\$");
                        List<String> lineData = Arrays.asList(values);
                        classification.put(lineData.get(0), lineData.get(2));
                    }
            }
            
            
            
                try (BufferedReader br = new BufferedReader(new FileReader(folder+fileName))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        String[] values = line.split(",");
                        List<String> lineData = Arrays.asList(values);
                        
                        if(lineData.get(10) != null && lineData.get(10).length() > 0){
                            
                            //System.out.println(lineData.get(10));
                            String location = lineData.get(9);
                            String ID = lineData.get(0); 
                            if(classification.get(ID).contains("REPUBLICAN")){
                                republican = republican+1;
                            }
                            else{
                                democtat = democtat+1;
                            }
                            
                            
                            for(int l = 0; l < 1; l++){
                                
                                    if(lineData.size() > 20){
                                        
                                        int inclinationDem = 0; int inclinationRep = 0; 
                                        if(classification.get(ID) != null && classification.get(ID).contains("REP")) inclinationRep = 1;  
                                        else inclinationDem = 1;
                                        if(analyticsHash.containsKey(normalize(location))){
                                            Analytics analytics = analyticsHash.get(normalize(location));
                                            analytics.setTweetCount(analytics.getTweetCount()+1);
                                            analytics.setInclinationDem(analytics.getInclinationDem()+inclinationDem);
                                            analytics.setInclinationRep(analytics.getInclinationRep()+inclinationRep);
                                            if(classification.get(ID) != null && !analytics.getClassification().contains(classification.get(ID))) analytics.setClassification("MIXED");
                                        }
                                        else{
                                            Analytics analytics = new Analytics(normalize(location), lineData.get(13), lineData.get(14), classification.get(ID), inclinationDem , inclinationRep );
                                            analyticsHash.put(normalize(location), analytics);
                                        }
                                    }
                                
                            }
                            
                            
                        }
                        
                        

                    }
                }
                
                ArrayList<Analytics> arrayList = new ArrayList<Analytics>(analyticsHash.size());
                arrayList.addAll(analyticsHash.values());
                
                analyticsSort(arrayList);
                int count = 0;
                for(int i = 0; i < 500; i++){
                    if(arrayList.get(i).getTweetCount() > 3){
                        System.out.println(arrayList.get(i));
                        count++;
                    }
                    if(count == 100) break;
                }
                
                
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    public static void analyticsHashTag(String folder, String fileName){
        try{
            
            int republican = 0;
            int democtat = 0;
            
            HashMap<String, Analytics> analyticsHash = new HashMap<>();
            HashMap<String, String> classification = new HashMap<>();
            
            try (BufferedReader br = new BufferedReader(new FileReader(folder+"MERGED_CLASS_0_3.csv"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        line = line.replaceAll("\\$\\$##\\$\\$", "\\$\\$");
                        String[] values = line.split("\\$\\$");
                        List<String> lineData = Arrays.asList(values);
                        classification.put(lineData.get(0), lineData.get(2));
                    }
            }
            
            
            
                try (BufferedReader br = new BufferedReader(new FileReader(folder+fileName))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        String[] values = line.split(",");
                        List<String> lineData = Arrays.asList(values);
                        
                        if(lineData.get(10) != null && lineData.get(10).length() > 0){
                            
                            //System.out.println(lineData.get(10));
                            String[] hashTags = lineData.get(10).split(" ");
                            List<String> hashTagList = Arrays.asList(hashTags);
                            String ID = lineData.get(0); 
                            if(classification.get(ID).contains("REPUBLICAN")){
                                republican = republican+1;
                            }
                            else{
                                democtat = democtat+1;
                            }
                            
                            
                            for(int l = 0; l < hashTagList.size(); l++){
                                
                                    if(lineData.size() > 20){
                                        
                                        int inclinationDem = 0; int inclinationRep = 0; 
                                        if(classification.get(ID) != null && classification.get(ID).contains("REP")) inclinationRep = 1;  
                                        else inclinationDem = 1;
                                        if(analyticsHash.containsKey(normalize(hashTagList.get(l)))){
                                            Analytics analytics = analyticsHash.get(normalize(hashTagList.get(l)));
                                            analytics.setTweetCount(analytics.getTweetCount()+1);
                                            analytics.setInclinationDem(analytics.getInclinationDem()+inclinationDem);
                                            analytics.setInclinationRep(analytics.getInclinationRep()+inclinationRep);
                                            if(classification.get(ID) != null && !analytics.getClassification().contains(classification.get(ID))) analytics.setClassification("MIXED");
                                        }
                                        else{
                                            Analytics analytics = new Analytics(normalize(hashTagList.get(l)), lineData.get(13), lineData.get(14), classification.get(ID), inclinationDem , inclinationRep );
                                            analyticsHash.put(normalize(hashTagList.get(l)), analytics);
                                        }
                                    }
                                
                            }
                            
                            
                        }
                        
                        

                    }
                }
                
                System.out.println("REPUBLICAN -> "+republican+","+(republican*100/26000)+", DEMOCTAT"+democtat+","+(democtat*100/14000));
                
                ArrayList<Analytics> arrayList = new ArrayList<Analytics>(analyticsHash.size());
                arrayList.addAll(analyticsHash.values());
                
                analyticsSort(arrayList);
                int count = 0;
                for(int i = 0; i < 500; i++){
                    if(arrayList.get(i).getTweetCount() > 3){
                        System.out.println(arrayList.get(i));
                        count++;
                    }
                    if(count == 35) break;
                }
                
                
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    public static void analyticsTopic(String folder, String fileName){
        try{
            
            HashMap<String, Analytics> analyticsHash = new HashMap<>();
            HashMap<String, String> classification = new HashMap<>();
            HashMap<String, String> topic = new HashMap<>();
            
            try (BufferedReader br = new BufferedReader(new FileReader(folder+"MERGED_CLASS_0_3.csv"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        line = line.replaceAll("\\$\\$##\\$\\$", "\\$\\$");
                        String[] values = line.split("\\$\\$");
                        List<String> lineData = Arrays.asList(values);
                        classification.put(lineData.get(0), lineData.get(2));
                    }
            }
            
            try (BufferedReader br = new BufferedReader(new FileReader(folder+"MERGED_TOPIC_0_3.csv"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        line = line.replaceAll("\\$\\$##\\$\\$", "\\$\\$").replaceAll("\"", "").toUpperCase();
                        String[] values = line.split("\\|");
                        List<String> lineData = Arrays.asList(values);
                        String topicMain = normalize(lineData.get(2)).replaceAll("\\'S","").replaceAll(": ", "")
                                        //.replaceAll("DONALD TRUMP", "DONALD-TRUMP")
                                        //.replaceAll("JOE BIDEN", "JOE-BIDEN")
                                        .replaceAll("TOPIC", "")
                                        .replaceAll("TRUMP CRITICISM", "DONALD TRUMP CRITICISM")
                                        .replaceAll("TRUMP SUPPORTER", "TRUMP SUPPORTERS")
                                        .replaceAll("BIDEN ADMINISTRATION CRITICISM", "BIDEN CRITICISM")
                                        .replaceAll("POLITICS BIDEN CRITICISM", "BIDEN CRITICISM").replaceAll("CRITICISM OF BIDEN", "BIDEN CRITICISM")
                                        .replaceAll("IMMIGRATION RHETORIC", "IMMIGRATION POLICY");
                                
                        topic.put(lineData.get(0), topicMain);
                    }
            }
            
            
            
                try (BufferedReader br = new BufferedReader(new FileReader(folder+fileName))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            if( line.trim().isEmpty() ) { continue; }
                            String[] values = line.split(",");
                            List<String> lineData = Arrays.asList(values);

                             String ID = lineData.get(0); 

                            if(topic.get(ID) != null){
                                for(int l = 0; l < 2; l++){ //hashTagList.size()

                                        if(lineData.size() > 20){

                                            int inclinationDem = 0; int inclinationRep = 0; 
                                            if(classification.get(ID) != null && classification.get(ID).contains("REP")) inclinationRep = 1;  
                                            else inclinationDem = 1;
                                            if(analyticsHash.containsKey(normalize(topic.get(ID)))){
                                                Analytics analytics = analyticsHash.get(normalize(topic.get(ID)));
                                                analytics.setTweetCount(analytics.getTweetCount()+1);
                                                analytics.setInclinationDem(analytics.getInclinationDem()+inclinationDem);
                                                analytics.setInclinationRep(analytics.getInclinationRep()+inclinationRep);
                                                //if(classification.get(ID) != null && !analytics.getClassification().contains(classification.get(ID))) analytics.setClassification("MIXED");
                                            }
                                            else{
                                                Analytics analytics = new Analytics(normalize(topic.get(ID)), lineData.get(13), lineData.get(14), classification.get(ID), inclinationDem , inclinationRep );
                                                analyticsHash.put(normalize(topic.get(ID)), analytics);
                                            }
                                        }

                                }
                        }
                    }
                }
                ArrayList<Analytics> arrayList = new ArrayList<Analytics>(analyticsHash.size());
                arrayList.addAll(analyticsHash.values());
                
                analyticsSort(arrayList);
                int count = 0;
                for(int i = 0; i < 500; i++){
                    if(arrayList.get(i).getTweetCount() > 3){
                        System.out.println(arrayList.get(i));
                        count++;
                    }
                    if(count == 45) break;
                }
                
                
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    public static void analyticsSort(ArrayList<Analytics> list) {

        list.sort((r1,r2)-> {
                        Integer seq1= new Integer(r1.getTweetCount());
                        Integer seq2= new Integer(r2.getTweetCount());
                        return seq2.compareTo(seq1);
        });
    } 
    
}
