
package zubi.thesis.deekseek.CSV;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Additional implements java.io.Serializable{
    
    public static String cleanText(String commentstr)
    {
        if(commentstr == null) return "";
        commentstr = commentstr.replaceAll("\\)", "");
        String urlPattern = "((https?|ftp|gopher|telnet|file|Unsure|http):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
        Pattern p = Pattern.compile(urlPattern,Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(commentstr);
        int i = 0;
        while (m.find()) {
            commentstr = commentstr.replaceAll(m.group(i),"").trim();
            i++;
        }
        commentstr = commentstr.replaceAll("@\\S+", "").replaceAll("\t", "");
        commentstr = commentstr.replaceAll("[^\\x20-\\x7e]", "").replaceAll("\"", "").replaceAll("\t", "");
        return commentstr.trim();
    }
    
    public static String superCleanText(String str){
        if(str == null) return str;
        else return cleanText(str).replaceAll("#\\S+", "").replaceAll("\t", "");
    }
    
}
