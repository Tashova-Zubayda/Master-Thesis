
package zubi.thesis.deekseek.CSV;

import zubi.thesis.deekseek.Models.Tweet;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CSVReader implements java.io.Serializable {
    
    private String inFile;
    private String outFile;    
    private String folder;
    
    public CSVReader(String folder){
        this.folder = folder;
        
        this.read("aug_chunk_61.csv", "AUG.csv");
        this.read("september_chunk_21.csv", "SEPT.csv");
        this.read("october_chunk_1.csv", "OCT.csv");
        
    }
    
    
    private void read(String inputFile, String outputFile){
        try{
            this.inFile = inputFile;
            this.outFile = outputFile;
            BufferedWriter writer = new BufferedWriter(new FileWriter(this.folder+this.outFile));
            if(this.inFile != null && this.outFile != null && this.folder != null){
                String entireRow = ""; int count = 0; StanfordNLP.init(); int tweetCount = 0;
                try (BufferedReader br = new BufferedReader(new FileReader(this.folder+this.inFile))) {
                    String line;
                    
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        if(count == 0){ count++; continue;}
                        
                        String[] values = line.split(",");
                        List<String> lineData = Arrays.asList(values);
                        

                        if(lineData.get(0).contains((count+1)+"")){
                            entireRow = entireRow.replaceAll("\n", "");
                            
                            if(entireRow.contains(",en,")){
                                String[] valuesMain = entireRow.split(",");
                                List<String> data = Arrays.asList(valuesMain);
                                String contentWithHashTags = this.readContent(entireRow, data.get(4));  // 2
                                String content = contentWithHashTags
                                                    .replaceAll("#\\w+", "")
                                                    .replaceAll("[^\\p{L}\\p{N}\\s’']", "")
                                                    .trim();
                                String hashTags = extractHashtags(contentWithHashTags);
                                System.out.println(hashTags);
                                if(content != null && content.length() > 20){
                                    Tweet tweet = new Tweet(
                                            data.get(2),  // 1
                                            content, 
                                            "EN",  
                                            hashTags
                                    );
                                    this.getCounts(entireRow, tweet);
                                    StanfordNLP.estimatingSentiment2(tweet); 
                                    
                                    tweet.setFOLLOWERS(this.getUserDetails(entireRow,"followersCount"));
                                    tweet.setFRIENDS(this.getUserDetails(entireRow,"friendsCount"));
                                    tweet.setFAVORITES(this.getUserDetails(entireRow,"favouritesCount"));
                                    tweet.setLISTED(this.getUserDetails(entireRow,"listedCount"));
                                    tweet.setMEDIA_COUNT(this.getUserDetails(entireRow,"mediaCount"));
                                    tweet.setSTATUSES_COUNT(this.getUserDetails(entireRow,"statusesCount"));
                                    tweet.setVERIFIED(this.getUserDetails(entireRow,"verified"));
                                    tweet.setLOCATION(this.getUserDetails(entireRow,"location"));
                                    tweet.setUSER_ID(this.getUserDetails(entireRow,"username"));
                                    tweet.setVIEW_COUNT(this.getUserDetails(entireRow,"count"));
                                    
                                    if(tweet.getLANG() != null && tweet.getLANG().contains("EN")){
                                       if(tweet.getCLEAN_TEXT2() != null && tweet.getCLEAN_TEXT2().trim().length() > 15){
                                          String[] words = tweet.getCLEAN_TEXT2().split(" ");
                                          if(words.length > 5){
                                              writer.write(tweet+"");
                                              writer.newLine();
                                              tweetCount++;
                                              if(tweetCount == 10000){
                                                  break;
                                              }
                                          }
                                       } 
                                    }
                                }
                            }
                            
                            entireRow = "";
                            count++;
                        }
                        entireRow = entireRow + line;
                    }
                }
                
                
            }
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
   
    
    
    
    /* Accessorial Functions */
    
    public String readContent(String line, String contentStr){
        try{
            if(line != null && contentStr != null) {
                if(contentStr.contains("\"")){
                    String[] values = line.split("\"");
                    if(values != null && values.length > 1){
                        return normalize( values[1] );
                    }
                }else{
                    return normalize(  contentStr );
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public String normalize(String str){
        if(str != null){
            return 
            Normalizer.normalize(str, Normalizer.Form.NFD)
                    // remove accents
                    .replaceAll("\\p{M}+", "")
                    // normalize curly quotes to straight apostrophe
                    .replaceAll("\u2018", "'")
                    .replaceAll("\u2019", "'")
                    // remove URLs
                    .replaceAll("https?://\\S+", "")
                    // remove @mentions
                    .replaceAll("@\\w+", "")
                    // remove commas
                    .replace(",", "")
                    // keep ASCII + apostrophe
                    .replaceAll("[^\\p{ASCII}']", "")
                    // collapse spaces
                    .replaceAll("\\s+", " ")
                    .trim();
        }
        return "";
    }
    
    public String extractHashtags(String input) {
        List<String> hashtags = new ArrayList<>();
        Pattern pattern = Pattern.compile("#\\w+");
        Matcher matcher = pattern.matcher(input);
        String hasTagsString = "";
        while (matcher.find()) {
            hasTagsString += ";"+matcher.group();
            hashtags.add(matcher.group());
        }
        
        return hasTagsString;
    }
    
    public void getCounts(String str, Tweet tweet){
        try{
            if(str != null){
                str = str.replaceAll("\"[^\"]*\"", "\"\"");
                String[] values = str.split(",");
                List<String> lineData = Arrays.asList(values);
                tweet.setREPLY_COUNT(lineData.get(14)); //12
                tweet.setRETWEET_COUNT(lineData.get(15)); //13
                tweet.setLIKE_COUNT(lineData.get(16)); //14
                tweet.setQUOTE_COUNT(lineData.get(17)); //15
            }
        }catch(Exception e){
           e.printStackTrace();
        }
    }
    
    public String getUserDetails(String main, String substring){
        try{
            if(main != null && substring != null){
                String[] values = main.split(",");
                List<String> lineData = Arrays.asList(values);
                
                for(String str : lineData){
                    if(str.trim().startsWith("'"+substring)){
                        return str.replace(substring, "").replace(":", "").replace("'", "").replace(",", "").trim();
                    }
                }
            }
        }catch(Exception e){
           e.printStackTrace();
        }
        return "";
    }
    
    
}
