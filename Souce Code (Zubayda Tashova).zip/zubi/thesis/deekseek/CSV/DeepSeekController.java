
package zubi.thesis.deekseek.CSV;

import zubi.thesis.deekseek.AdvancedDeepSeekClient;
import zubi.thesis.deekseek.Models.DeepSeek;
import zubi.thesis.deekseek.Models.DeepSeekTopic;
import zubi.thesis.deekseek.Models.Tweet;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class DeepSeekController implements java.io.Serializable {
    private String folder;
    private String file;
    private HashMap<String, String> mapTopic= new HashMap<>();
    public BufferedWriter writer;

    public DeepSeekController(String folder, String file) {
        this.folder = folder;
        this.file = file;
        try{
             this.writer = new BufferedWriter(new FileWriter(this.folder+this.file, true));
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void deepSeek_classification(String fileName){
        try{
            this.getIds();
            AdvancedDeepSeekClient client = new AdvancedDeepSeekClient();
            if(this.file != null && this.folder != null){
                try (BufferedReader br = new BufferedReader(new FileReader(this.folder+fileName))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String[] values = line.split(",");
                        if(values != null && values.length > 0 ){
                           String ID = values[0];
                           String TEXT = values[2];
                           
                           if(TEXT != null && !mapTopic.containsKey(ID)){
                                String[] words = TEXT.split(" ");
                                if(words != null && words.length > 5){
                                    String RESPONSE = client.chatCompletion(
                                            "Respond with only one word pro-Republican or pro-Democrat => "+TEXT
                                    );
                                    DeepSeek deepSeek = new DeepSeek(ID, TEXT, RESPONSE);
                                    this.writer = new BufferedWriter(new FileWriter(this.folder+this.file, true));
                                    System.out.println(deepSeek);
                                    writer.write(deepSeek+"");
                                    writer.newLine();
                                    writer.close();
                                   //break; //#IMPORTANT
                                }
                           }
                        }
                    }
                }
              }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    public void getIds(){
        try{
               
                try (BufferedReader br = new BufferedReader(new FileReader("D:\\DataSet\\"+this.file))) {
                    String line;
                    
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        line = line.replaceAll("$$##$$", "##");
                        String[] values = line.split("##");
                        mapTopic.put(values[0].replaceAll("\\$", ""), values[0].replaceAll("\\$", ""));
                        //System.out.println(values[0].replaceAll("\\$", ""));
                    }
                }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void deepSeek_topic(String fileName){
        try{
            this.getIds();
            AdvancedDeepSeekClient client = new AdvancedDeepSeekClient();
            if(this.file != null && this.folder != null){
                try (BufferedReader br = new BufferedReader(new FileReader(this.folder+fileName))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String[] values = line.split(",");
                        if(values != null && values.length > 0 ){
                           String ID = values[0];
                           String TEXT = values[2];
                           
                           if(TEXT != null && !mapTopic.containsKey(ID)){
                                String[] words = TEXT.split(" ");
                                if(words != null && words.length > 5){
                                    String RESPONSE = client.chatCompletion(
                                            "What is the topic of the following tweet in 2-3 words => "+TEXT
                                    );
                                    
                                    Pattern pattern = Pattern.compile("\"content\"\\s*:\\s*(.*?)\\s*}");
                                    
                                    Matcher matcher = pattern.matcher(RESPONSE);
                                    
                                    String RESULT = "NOT AVAILABLE";
                                    
                                    if (matcher.find()) {
                                        RESULT = matcher.group(1);
                                    }
                                    DeepSeekTopic deepSeek = new DeepSeekTopic(ID, TEXT,RESULT, RESPONSE);
                                    this.writer = new BufferedWriter(new FileWriter(this.folder+this.file, true));
                                    System.out.println(deepSeek);
                                    writer.write(deepSeek+"");
                                    writer.newLine();
                                    writer.close();
                                   //break; //#IMPORTANT
                                }
                           }
                        }
                    }
                }
              }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    
    public void deepSeek_sentiment(String fileName){
        try{
            this.getIds();
            AdvancedDeepSeekClient client = new AdvancedDeepSeekClient();
            if(this.file != null && this.folder != null){
                try (BufferedReader br = new BufferedReader(new FileReader(this.folder+fileName))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String[] values = line.split(",");
                        if(values != null && values.length > 0 ){
                           String ID = values[0];
                           String TEXT = values[2];
                           
                           if(TEXT != null && !mapTopic.containsKey(ID)){
                                String[] words = TEXT.split(" ");
                                if(words != null && words.length > 5){
                                    String RESPONSE = client.chatCompletion(
                                            "What is tone of the following tweet in a single word (Positive, Negative, Neutral) => "+TEXT
                                    );
                                    
                                    Pattern pattern = Pattern.compile("\"content\"\\s*:\\s*(.*?)\\s*}");
                                    
                                    Matcher matcher = pattern.matcher(RESPONSE);
                                    
                                    String RESULT = "NOT AVAILABLE";
                                    
                                    if (matcher.find()) {
                                        RESULT = matcher.group(1);
                                    }
                                    DeepSeekTopic deepSeek = new DeepSeekTopic(ID, TEXT,RESULT, RESPONSE);
                                    this.writer = new BufferedWriter(new FileWriter(this.folder+this.file, true));
                                    System.out.println(deepSeek);
                                    writer.write(deepSeek+"");
                                    writer.newLine();
                                    writer.close();
                                   //break; //#IMPORTANT
                                }
                           }
                        }
                    }
                }
              }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
}
