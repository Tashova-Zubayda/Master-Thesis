
package zubi.thesis.deekseek;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.*;

public class AdvancedDeepSeekClient implements java.io.Serializable {
    private static final String API_KEY = "";
    private static final String API_URL = "https://api.deepseek.com/chat/completions";
    private final HttpClient client;
    private final ObjectMapper mapper;
    
    public AdvancedDeepSeekClient() {
        this.client = HttpClient.newHttpClient();
        this.mapper = new ObjectMapper();
    }
    
    public static class ChatMessage {
        public String role;
        public String content;
        
        public ChatMessage(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }
    
    public static class ChatRequest {
        public String model = "deepseek-chat";
        public List<ChatMessage> messages = new ArrayList<>();
        public boolean stream = false;
        public Integer max_tokens = 2048;
        public Double temperature = 0.7;
    }
    
    public static class ChatResponse {
        public List<Choice> choices;
        
        public static class Choice {
            public ChatMessage message;
        }
    }
    
    public String chatCompletion(String message) throws Exception {
        //ChatRequest request = new ChatRequest();
        //request.messages = messages;
        
        /* Added Code */
        Map<String, Object> requestPayload = new HashMap<>();
        requestPayload.put("model", "deepseek-chat");
        requestPayload.put("messages", new Object[] {
            Map.of("role", "user", "content", message)
        });
        requestPayload.put("max_tokens", 20);  // Key parameter
        requestPayload.put("temperature", 0.1); // Lower temperature for more predictable short responses
        
        /* Added Code */
        
        String requestBody = mapper.writeValueAsString(requestPayload);
        
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(API_URL))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + API_KEY)
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();
        
        HttpResponse<String> response = client.send(
            httpRequest, 
            HttpResponse.BodyHandlers.ofString()
        );
        
        if (response.statusCode() == 200) {
            
            return response.body();
            
        } else {
            return "###ERROR###";
        }
    }
}