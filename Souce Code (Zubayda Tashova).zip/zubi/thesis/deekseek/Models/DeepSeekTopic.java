
package zubi.thesis.deekseek.Models;


public class DeepSeekTopic implements java.io.Serializable{
    private String ID;
    private String TWEET;
    private String TOPIC;
    private String FULL_RESPONSE;

    public DeepSeekTopic(String ID, String TWEET, String TOPIC, String FULL_RESPONSE) {
        this.ID = ID;
        this.TWEET = TWEET;
        this.FULL_RESPONSE = FULL_RESPONSE;
        this.TOPIC = TOPIC;
       
        
    }

    @Override
    public String toString() {
        return  ID + "$$##$$" + TWEET + "$$##$$" + TOPIC + "$$##$$" + FULL_RESPONSE;
    }
    
    

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTWEET() {
        return TWEET;
    }

    public void setTWEET(String TWEET) {
        this.TWEET = TWEET;
    }

    public String getTOPIC() {
        return TOPIC;
    }

    public void setTOPIC(String TOPIC) {
        this.TOPIC = TOPIC;
    }
    

    public String getFULL_RESPONSE() {
        return FULL_RESPONSE;
    }

    public void setFULL_RESPONSE(String FULL_RESPONSE) {
        this.FULL_RESPONSE = FULL_RESPONSE;
    }
}
