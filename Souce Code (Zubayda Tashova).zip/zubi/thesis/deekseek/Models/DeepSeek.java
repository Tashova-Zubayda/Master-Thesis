package zubi.thesis.deekseek.Models;


public class DeepSeek implements java.io.Serializable{
    private String ID;
    private String TWEET;
    private String CLASSIFICATION;
    private String FULL_RESPONSE;

    public DeepSeek(String ID, String TWEET, String FULL_RESPONSE) {
        this.ID = ID;
        this.TWEET = TWEET;
        this.FULL_RESPONSE = FULL_RESPONSE;
        
        if(FULL_RESPONSE != null && FULL_RESPONSE.contains("\"content\":\"pro-Republican\"")){
            this.CLASSIFICATION = "REPUBLICAN";
        }
        else if(FULL_RESPONSE != null && FULL_RESPONSE.contains("\"content\":\"pro-Democrat\"")){
            this.CLASSIFICATION = "DEMOCRAT";
        }
        else{
            this.CLASSIFICATION = "NOT AVAILABLE";
        }
        
    }

    @Override
    public String toString() {
        return  ID + "$$##$$" + TWEET + "$$##$$" + CLASSIFICATION + "$$##$$" + FULL_RESPONSE;
    }
    
    

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTWEET() {
        return TWEET;
    }

    public void setTWEET(String TWEET) {
        this.TWEET = TWEET;
    }

    public String getCLASSIFICATION() {
        return CLASSIFICATION;
    }

    public void setCLASSIFICATION(String CLASSIFICATION) {
        this.CLASSIFICATION = CLASSIFICATION;
    }

    public String getFULL_RESPONSE() {
        return FULL_RESPONSE;
    }

    public void setFULL_RESPONSE(String FULL_RESPONSE) {
        this.FULL_RESPONSE = FULL_RESPONSE;
    }

}
