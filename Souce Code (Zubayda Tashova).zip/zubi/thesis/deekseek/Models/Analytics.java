
package zubi.thesis.deekseek.Models;


public class Analytics implements java.io.Serializable {
    
    private String name;
    
    private int tweetCount;
    
    private String followersCount;
    
    private String friendsCount;
    
    private String classification;
    
    private String sentiment;
    
    private int sentimentPos;
    private int sentimentNeg;
    
    private int inclinationDem;
    private int inclinationRep;

    public Analytics(String name, String followersCount, String friendsCount, String classification, int inclinationDem, int inclnationRep) {
        this.name = name;
        this.followersCount = followersCount;
        this.friendsCount = friendsCount;
        this.classification = classification;
        this.tweetCount = 1;
        this.inclinationDem = inclinationDem;
        this.inclinationRep = inclnationRep;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTweetCount() {
        return tweetCount;
    }

    public void setTweetCount(int tweetCount) {
        this.tweetCount = tweetCount;
    }

    public String getFollowersCount() {
        return followersCount;
    }

    public void setFollowersCount(String followersCount) {
        this.followersCount = followersCount;
    }

    public String getFriendsCount() {
        return friendsCount;
    }

    public void setFriendsCount(String friendsCount) {
        this.friendsCount = friendsCount;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public int getInclinationDem() {
        return inclinationDem;
    }

    public void setInclinationDem(int inclinationDem) {
        this.inclinationDem = inclinationDem;
    }

    public int getInclinationRep() {
        return inclinationRep;
    }

    public void setInclinationRep(int inclinationRep) {
        this.inclinationRep = inclinationRep;
    }

    public String getSentiment() {
        return sentiment;
    }

    public void setSentiment(String sentiment) {
        this.sentiment = sentiment;
    }

    public int getSentimentPos() {
        return sentimentPos;
    }

    public void setSentimentPos(int sentimentPos) {
        this.sentimentPos = sentimentPos;
    }

    public int getSentimentNeg() {
        return sentimentNeg;
    }

    public void setSentimentNeg(int sentimentNeg) {
        this.sentimentNeg = sentimentNeg;
    }
    
    
    
    @Override
    public String toString() {
        int data = (inclinationDem-inclinationRep); double percentage = 1;
        int someData = 0;
        if(inclinationDem > 0 && inclinationRep > 0){
            
            //classification = "NEUTRAL";
            
            if(data < 0){
                someData = inclinationRep;
                percentage = (double)(inclinationRep*100 / tweetCount); percentage = inclinationRep*100;
                if((inclinationRep*100 / tweetCount) >= 70){
                    classification = "MIXED-REPUBLICAN";
                }
            }
            else{
                   someData = inclinationDem;
                    percentage = (double)(inclinationDem*100 / tweetCount); percentage = inclinationDem*100;
                    if((inclinationDem*100 / tweetCount) >= 70){
                     classification = "MIXED-DEMOCRAT";
                    }
            }
        }
        
        
        
        {
            
        }
        
        if(classification.contains("MIXED")){
            return  name + "," + tweetCount + "," + followersCount + "," + someData + "," + classification + "," + (percentage/tweetCount);
        }
        else{
            return  name + "," + tweetCount + "," + followersCount + "," + friendsCount + "," + classification + ",100";
        }
        
        
    }
}
