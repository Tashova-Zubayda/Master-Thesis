
package zubi.thesis.deekseek.Models;


public class Tweet implements java.io.Serializable{
   
    
    private String ID; 
    private String TEXT; 
    private String CLEAN_TEXT2; 
    private String LANG; 
    private String REPLY_COUNT;
    private String RETWEET_COUNT;
    private String LIKE_COUNT;
    private String QUOTE_COUNT;
    private String VIEW_COUNT;
    private String LOCATION;
    private String HASHTAGS;
    private String SENTIMENT;
    private String SENTIMENT_SCORE;
    private String FOLLOWERS;
    private String FRIENDS;
    private String FAVORITES;
    private String LISTED;
    private String MEDIA_COUNT;
    private String STATUSES_COUNT;
    private String VERIFIED;
    private String USER_ID;
    
    
    public Tweet(){}

    public Tweet(String ID, String TEXT, String LANG, String HASHTAGS) {
        this.ID = ID;
        this.TEXT = TEXT;
        this.LANG = LANG;
        this.HASHTAGS = HASHTAGS.replace(";", " ").trim();
    }
    

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTEXT() {
        return TEXT;
    }

    public void setTEXT(String TEXT) {
        this.TEXT = TEXT;
    }

    public String getLANG() {
        return LANG;
    }

    public void setLANG(String LANG) {
        this.LANG = LANG;
    }

    public String getREPLY_COUNT() {
        return REPLY_COUNT;
    }

    public void setREPLY_COUNT(String REPLY_COUNT) {
        this.REPLY_COUNT = REPLY_COUNT;
    }

    public String getRETWEET_COUNT() {
        return RETWEET_COUNT;
    }

    public void setRETWEET_COUNT(String RETWEET_COUNT) {
        this.RETWEET_COUNT = RETWEET_COUNT;
    }

    public String getLIKE_COUNT() {
        return LIKE_COUNT;
    }

    public void setLIKE_COUNT(String LIKE_COUNT) {
        this.LIKE_COUNT = LIKE_COUNT;
    }

    public String getQUOTE_COUNT() {
        return QUOTE_COUNT;
    }

    public void setQUOTE_COUNT(String QUOTE_COUNT) {
        this.QUOTE_COUNT = QUOTE_COUNT;
    }

    public String getLOCATION() {
        return LOCATION;
    }

    public void setLOCATION(String LOCATION) {
        this.LOCATION = LOCATION;
    }

    public String getVIEW_COUNT() {
        return VIEW_COUNT;
    }

    public void setVIEW_COUNT(String VIEW_COUNT) {
        this.VIEW_COUNT = VIEW_COUNT;
    }

    public String getHASHTAGS() {
        return HASHTAGS;
    }

    public void setHASHTAGS(String HASHTAGS) {
        this.HASHTAGS = HASHTAGS;
    }

    public String getSENTIMENT() {
        return SENTIMENT;
    }

    public void setSENTIMENT(String SENTIMENT) {
        this.SENTIMENT = SENTIMENT;
    }

    public String getSENTIMENT_SCORE() {
        return SENTIMENT_SCORE;
    }

    public void setSENTIMENT_SCORE(String SENTIMENT_SCORE) {
        this.SENTIMENT_SCORE = SENTIMENT_SCORE;
    }
    
    public String getCLEAN_TEXT2() {
        return CLEAN_TEXT2;
    }

    public void setCLEAN_TEXT2(String CLEAN_TEXT2) {
        this.CLEAN_TEXT2 = CLEAN_TEXT2;
    }

    public String getFOLLOWERS() {
        return FOLLOWERS;
    }

    public void setFOLLOWERS(String FOLLOWERS) {
        this.FOLLOWERS = FOLLOWERS;
    }

    public String getFRIENDS() {
        return FRIENDS;
    }

    public void setFRIENDS(String FRIENDS) {
        this.FRIENDS = FRIENDS;
    }

    public String getFAVORITES() {
        return FAVORITES;
    }

    public void setFAVORITES(String FAVORITES) {
        this.FAVORITES = FAVORITES;
    }

    public String getLISTED() {
        return LISTED;
    }

    public void setLISTED(String LISTED) {
        this.LISTED = LISTED;
    }

    public String getMEDIA_COUNT() {
        return MEDIA_COUNT;
    }

    public void setMEDIA_COUNT(String MEDIA_COUNT) {
        this.MEDIA_COUNT = MEDIA_COUNT;
    }

    public String getSTATUSES_COUNT() {
        return STATUSES_COUNT;
    }

    public void setSTATUSES_COUNT(String STATUSES_COUNT) {
        this.STATUSES_COUNT = STATUSES_COUNT;
    }

    public String getVERIFIED() {
        return VERIFIED;
    }

    public void setVERIFIED(String VERIFIED) {
        this.VERIFIED = VERIFIED;
    }

    public String getUSER_ID() {
        return USER_ID;
    }

    public void setUSER_ID(String USER_ID) {
        this.USER_ID = USER_ID;
    }

    @Override
    public String toString() {
        return  ID + "," + TEXT + "," + CLEAN_TEXT2 + "," + LANG + "," + REPLY_COUNT + "," + RETWEET_COUNT + "," + LIKE_COUNT + "," + QUOTE_COUNT + "," + VIEW_COUNT + "," + LOCATION + "," + HASHTAGS + "," + SENTIMENT + "," + SENTIMENT_SCORE + "," + FOLLOWERS + "," + FRIENDS + "," + FAVORITES + "," + LISTED + "," + MEDIA_COUNT + "," + STATUSES_COUNT + "," + VERIFIED + "," + USER_ID;
    }
    
    
//    @Override
//    public String toString() {
//        return  ID + "," + TEXT + ",#CLEAN:" + CLEAN_TEXT2 + ",#LANG:" + LANG + ",#REPLY:" + REPLY_COUNT + ",#RETWEET:" + RETWEET_COUNT + ",#LIKE:" + LIKE_COUNT + ",#QUOTE:" + QUOTE_COUNT + ",#VIEW:" + VIEW_COUNT + ",#LOCATION:" + LOCATION + ",#HASH:" + HASHTAGS + "," + SENTIMENT + "," + SENTIMENT_SCORE + "," + FOLLOWERS + "," + FRIENDS + "," + FAVORITES + "," + LISTED + "," + MEDIA_COUNT + "," + STATUSES_COUNT + "," + VERIFIED + "," + USER_ID;
//    }

    
}
