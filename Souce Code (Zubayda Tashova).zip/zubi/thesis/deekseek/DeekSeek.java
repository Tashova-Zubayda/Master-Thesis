/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zubi.thesis.deekseek;

import zubi.thesis.deekseek.CSV.CSVReader;
import zubi.thesis.deekseek.CSV.DeepSeekController;
import zubi.thesis.deekseek.Models.Analytics;
import java.io.BufferedReader;
import java.io.FileReader;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class DeekSeek {
    
    
    public static void main(String[] args){
        try{

            AnalyticsMain.analyticsLocation("","");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
     public static void readForBI(String folder, String fileName){
        try{
                try (BufferedReader br = new BufferedReader(new FileReader(folder+fileName))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        //line = line.replaceAll("\\$\\$##\\$\\$", "\\$\\$");
                        String[] values = line.split("\\|"); //line.split("\\$\\$");
                        List<String> lineData = Arrays.asList(values);
                        
                        String data = lineData.get(2).toUpperCase().replaceAll("'S", "");
                        String[] arr = data.split(" "); 
                            
                        for(int i = 0; i < arr.length; i++){
                            if(arr[i].replaceAll("[^a-zA-Z]", "").length() > 0){
                                System.out.println(lineData.get(0)+","+arr[i].replaceAll("[^a-zA-Z]", "")); 
                            }
                        }
                        //System.out.println(lineData.get(0)+","+data);
                    }
                }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
     
     
     public static void analytics(String folder, String fileName){
        try{
            HashMap<String, Analytics> analyticsHash = new HashMap<>();
            HashMap<String, String> classification = new HashMap<>();
            
            try (BufferedReader br = new BufferedReader(new FileReader(folder+"MERGED_CLASS_0_3.csv"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        line = line.replaceAll("\\$\\$##\\$\\$", "\\$\\$");
                        String[] values = line.split("\\$\\$");
                        List<String> lineData = Arrays.asList(values);
                        classification.put(lineData.get(0), lineData.get(2));
                    }
            }
            
            
            
                try (BufferedReader br = new BufferedReader(new FileReader(folder+fileName))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if( line.trim().isEmpty() ) { continue; }
                        String[] values = line.split(",");
                        List<String> lineData = Arrays.asList(values);
                        
                        if(lineData.size() > 20){
                            
                            String ID = lineData.get(0); int inclinationDem = 0; int inclinationRep = 0; 
                            if(classification.get(ID) != null && classification.get(ID).contains("REP")) inclinationRep = 1;  
                            else inclinationDem = 1;
                            if(analyticsHash.containsKey(normalize(lineData.get(20)))){
                                Analytics analytics = analyticsHash.get(normalize(lineData.get(20)));
                                analytics.setTweetCount(analytics.getTweetCount()+1);
                                analytics.setInclinationDem(analytics.getInclinationDem()+inclinationDem);
                                analytics.setInclinationRep(analytics.getInclinationRep()+inclinationRep);
                                if(classification.get(ID) != null && !analytics.getClassification().contains(classification.get(ID))) analytics.setClassification("MIXED");
                            }
                            else{
                                Analytics analytics = new Analytics(normalize(lineData.get(20)), lineData.get(13), lineData.get(14), classification.get(ID), inclinationDem , inclinationRep );
                                analyticsHash.put(normalize(lineData.get(20)), analytics);
                            }
                        }
                    }
                }
                
                ArrayList<Analytics> arrayList = new ArrayList<Analytics>(analyticsHash.size());
                arrayList.addAll(analyticsHash.values());
                
                analyticsSort(arrayList);
                int count = 0;
                for(int i = 0; i < 500; i++){
                    if(arrayList.get(i).getTweetCount() > 3){
                        System.out.println(arrayList.get(i));
                        count++;
                    }
                    if(count == 25) break;
                }
                
                
        }catch(Exception e){
            e.printStackTrace();
        }
    }
     
    public static void analyticsSort(ArrayList<Analytics> list) {

        list.sort((r1,r2)-> {
                        Integer seq1= new Integer(r1.getFriendsCount());
                        Integer seq2= new Integer(r2.getFriendsCount());
                        return seq2.compareTo(seq1);
        });
    } 
     
    
    public static void argument(String arg){
        if(arg == null) return;
        
        if(arg.contains("CLASS")){
             System.out.println("CLASS");
             DeepSeekController deepSeek1 = new DeepSeekController("D:\\DataSet\\","CLASS_1K.csv");
             deepSeek1.deepSeek_classification("AUG.CSV");
             
             DeepSeekController deepSeek2 = new DeepSeekController("D:\\DataSet\\","CLASS_2K.csv");
             deepSeek2.deepSeek_classification("SEPT.CSV");
             
             DeepSeekController deepSeek3 = new DeepSeekController("D:\\DataSet\\","CLASS_3K.csv");
             deepSeek3.deepSeek_classification("OCT.CSV");
            
        }
        else if(arg.contains("TOPIC")){
            System.out.println("TOPIC");
             DeepSeekController deepSeek1 = new DeepSeekController("D:\\DataSet\\","TOPIC_1K.csv");
             deepSeek1.deepSeek_topic("AUG.CSV");
             
             DeepSeekController deepSeek2 = new DeepSeekController("D:\\DataSet\\","TOPIC_2K.csv");
             deepSeek2.deepSeek_topic("SEPT.CSV");
             
             DeepSeekController deepSeek3 = new DeepSeekController("D:\\DataSet\\","TOPIC_3K.csv");
             deepSeek3.deepSeek_topic("OCT.CSV");
        }
        else if(arg.contains("SENTIM")){
            System.out.println("SENTIM");
             DeepSeekController deepSeek1 = new DeepSeekController("D:\\DataSet\\","SENTIM_1K.csv");
             deepSeek1.deepSeek_sentiment("AUG.CSV");
             
             DeepSeekController deepSeek2 = new DeepSeekController("D:\\DataSet\\","SENTIM_2K.csv");
             deepSeek2.deepSeek_sentiment("SEPT.CSV");
             
             DeepSeekController deepSeek3 = new DeepSeekController("D:\\DataSet\\","SENTIM_3K.csv");
             deepSeek3.deepSeek_sentiment("OCT.CSV");
        }
    }
    
    public static String normalize(String str){
        if(str != null){
//            return Normalizer.normalize(str, Normalizer.Form.NFD)
//                    .replaceAll("[^\\p{ASCII}’']", "").replace(",", "")
//                    .replaceAll("@\\w+", "")
//                    .replaceAll(" +", " ")
//                    .replaceAll("https://\\S+", "")
//                    .trim();
            
            String str1 = Normalizer.normalize(str, Normalizer.Form.NFD)
                    // remove accents
                    .replaceAll("\\p{M}+", "")
                    // normalize curly quotes to straight apostrophe
                    .replace("\u2018", "'")
                    .replace("\u2019", "'")
                    // remove URLs
                    .replaceAll("https?://\\S+", "")
                    // remove @mentions
                    .replaceAll("@\\w+", "")
                    // remove commas
                    .replace(",", "")
                    // keep ASCII + apostrophe
                    .replaceAll("[^\\p{ASCII}']", "")
                    // collapse spaces
                    .replaceAll("\\s+", " ")
                    .trim();
            
            if(str1.length() < 1) return "NO-NAME";
            else { return str1;}
        }
        return "";
    }
    
}
